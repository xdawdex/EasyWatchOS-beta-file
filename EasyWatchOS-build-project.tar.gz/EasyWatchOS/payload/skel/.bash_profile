#
# ~/.bash_profile
#

[[ -f ~/.bashrc ]] && . ~/.bashrc

# Text-mode dashboard on tty1 (no display server running)
if [ -z "${WAYLAND_DISPLAY:-}" ] && [ -z "${DISPLAY:-}" ] &&
    [ "$(tty 2>/dev/null)" = "/dev/tty1" ] &&
    [ -x "$HOME/.local/bin/tty-dashboard" ]; then
    "$HOME/.local/bin/tty-dashboard"
fi
