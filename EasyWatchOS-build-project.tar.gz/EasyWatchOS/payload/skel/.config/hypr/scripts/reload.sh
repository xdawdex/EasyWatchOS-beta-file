#!/bin/bash
# Reload Hyprland config
hyprctl reload
