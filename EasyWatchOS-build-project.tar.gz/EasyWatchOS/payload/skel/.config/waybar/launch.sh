#!/bin/bash
# Launch waybar - single instance only
killall -q waybar
sleep 0.5
/usr/bin/waybar &
