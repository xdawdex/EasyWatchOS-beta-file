#!/bin/bash
# Toggle waybar on/off with SUPER+SHIFT+Z
if pgrep -x waybar > /dev/null; then
    killall -q waybar
else
    /home/xdawdex/.config/waybar/launch.sh
fi
