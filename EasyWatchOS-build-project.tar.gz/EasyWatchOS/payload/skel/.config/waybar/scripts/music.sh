#!/bin/bash
# Music widget for waybar - works with Spotify/playerctl
# Usage: music.sh           -> print status
#        music.sh toggle    -> play/pause
#        music.sh next      -> next track
#        music.sh previous  -> previous track

case "$1" in
    toggle)
        playerctl play-pause 2>/dev/null
        ;;
    next)
        playerctl next 2>/dev/null
        ;;
    previous|prev)
        playerctl previous 2>/dev/null
        ;;
    *)
        status=$(playerctl status 2>/dev/null)
        artist=$(playerctl metadata --format '{{artist}}' 2>/dev/null)
        title=$(playerctl metadata --format '{{title}}' 2>/dev/null)

        icon="[stop]"
        case "$status" in
            Playing) icon="[play]" ;;
            Paused)  icon="[pause]" ;;
        esac

        if [ -n "$title" ] && [ -n "$artist" ]; then
            printf '%s %s - %s' "$icon" "$artist" "$title"
        elif [ -n "$title" ]; then
            printf '%s %s' "$icon" "$title"
        else
            case "$status" in
                Playing|Paused) echo "$icon  $status" ;;
                *)              echo "[stop]  no music" ;;
            esac
        fi
        ;;
esac
