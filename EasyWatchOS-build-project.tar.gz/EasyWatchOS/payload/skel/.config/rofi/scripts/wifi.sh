#!/bin/bash
# Rofi WiFi picker for Waybar's network module.
# Left click on the network widget runs this: pick a network, enter password, connect.

notify() {
    hyprctl notify -1 3500 "rgb(ffffff)" "$1" >/dev/null 2>&1 || notify-send "WiFi" "$1" 2>/dev/null
}

# make sure wifi radio is on
if ! nmcli radio wifi | grep -q "^enabled"; then
    nmcli radio wifi on
fi

# refresh scan
nmcli device wifi rescan >/dev/null 2>&1
sleep 1

# build list: SSID<TAB>signal%<TAB>security   (deduplicated, no hidden)
list=$(nmcli -t -f SSID,SIGNAL,SECURITY device wifi list 2>/dev/null \
    | awk -F: '!seen[$1]++ && $1!="" { sec=($3=="")?"open":$3; printf "%s\t%s%%\t%s\n", $1, $2, sec }')

if [ -z "$list" ]; then
    notify "No WiFi networks found"
    exit 0
fi

chosen=$(printf '%s\n' "$list" | rofi -dmenu -i -p "WiFi" -no-custom -format 's')
[ -z "$chosen" ] && exit 0

ssid=$(printf '%s' "$chosen" | cut -f1)
security=$(printf '%s' "$chosen" | cut -f3)

# already have a saved connection with this name?
if nmcli -t -f NAME connection show 2>/dev/null | grep -qxF "$ssid"; then
    out=$(nmcli connection up "$ssid" 2>&1)
    if [ $? -eq 0 ]; then
        notify "Connected to $ssid"
    else
        notify "Failed: $ssid"
    fi
    exit 0
fi

if [ "$security" = "open" ]; then
    out=$(nmcli device wifi connect "$ssid" 2>&1)
else
    pass=$(rofi -dmenu -password -p "Password: $ssid" )
    [ -z "$pass" ] && exit 0
    out=$(nmcli device wifi connect "$ssid" password "$pass" 2>&1)
fi

if [ $? -eq 0 ]; then
    notify "Connected to $ssid"
else
    notify "Failed: $ssid"
fi
