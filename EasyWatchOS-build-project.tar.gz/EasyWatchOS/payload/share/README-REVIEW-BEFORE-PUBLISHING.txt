EasyWatch OS source payload
===========================

This directory is copied into the live ISO at /usr/local/share/easywatch.

Before publishing a public ISO/repository:
- Review software licenses and attribution for all bundled applications.
- Review all package redistribution and trademark requirements.
- Verify that no personal credentials, Wi-Fi profiles, SSH keys, tokens,
  browser profiles, private histories, or machine-specific identifiers are included.
- Verify the installer writes only to the disk explicitly selected by its user.
