#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROFILE="$ROOT/profile"
RELENG="/usr/share/archiso/configs/releng"

if [[ ! -d "$RELENG" ]]; then
    echo "Archiso releng profile not found at $RELENG."
    echo "Install the archiso package on the BUILD HOST, then run this script again."
    exit 1
fi

# Refresh the profile from the installed official Archiso releng template.
find "$PROFILE" -mindepth 1 -maxdepth 1 -exec rm -rf -- {} +
cp -a "$RELENG/." "$PROFILE/"

# Preserve the full source-system package selection and add ISO/install support.
cp "$ROOT/packages.x86_64" "$PROFILE/packages.x86_64"

# Overlay files for the live environment. These are also the template for
# the later installer integration; no disks are touched by this script.
mkdir -p "$PROFILE/airootfs/etc/skel"
cp -a "$ROOT/payload/skel/." "$PROFILE/airootfs/etc/skel/"
mkdir -p "$PROFILE/airootfs/usr/local/share/easywatch"
cp -a "$ROOT/payload/share/." "$PROFILE/airootfs/usr/local/share/easywatch/"

# Archiso normalizes overlay files to mode 0644 unless file_permissions
# is set in profiledef.sh. Add explicit executable permissions for scripts.
cat >> "$PROFILE/profiledef.sh" <<'PERMISSIONS'

file_permissions+=(
  ["/etc/skel/.local/bin/tty-dashboard"]="0:0:755"
  ["/etc/skel/.local/bin/wifi-tui"]="0:0:755"
  ["/etc/skel/.local/bin/bluetooth-tui"]="0:0:755"
  ["/etc/skel/.local/bin/volume-tui"]="0:0:755"
  ["/etc/skel/.local/bin/audio-autoswitch"]="0:0:755"
  ["/etc/skel/.local/bin/bluetooth-autoconnect"]="0:0:755"
  ["/etc/skel/.local/bin/ani-cli"]="0:0:755"
  ["/etc/skel/.local/bin/luffy"]="0:0:755"
  ["/etc/skel/.config/waybar/launch.sh"]="0:0:755"
  ["/etc/skel/.config/waybar/scripts/music.sh"]="0:0:755"
  ["/etc/skel/.config/waybar/scripts/toggle.sh"]="0:0:755"
  ["/etc/skel/.config/hypr/scripts/reload.sh"]="0:0:755"
  ["/etc/skel/.config/rofi/scripts/wifi.sh"]="0:0:755"
)
PERMISSIONS

echo "Prepared Archiso profile at: $PROFILE"
echo "Review it before building. This step does not build an ISO."
