# EasyWatch OS — build project (initial profile preparation)

This project is based on the supplied `EasyWatchOS-source` collection.
It preserves the captured package inventory and selected user files.

## Current contents

- `packages.x86_64`: all 626 packages captured from the source installation,
  plus `archinstall` and `mkinitcpio-archiso`.
- `payload/skel/`: dashboard, helper programs, Luffy binary, selected configs,
  and user services for a live user's home directory.
- `prepare-profile.sh`: copies the official Archiso `releng` template from
  the installed `archiso` package and overlays the EasyWatch payload.
- `build-iso.sh`: invokes `mkarchiso` to build an ISO from the prepared profile.
- `package-inventory/`: original package inventories for audit.

## Important status

**This is an initial build scaffold, not yet a finished installable release.**
The live ISO profile and package payload are staged, but the installer still
needs integration so that it:
1. asks the installer user to choose a username and password;
2. installs the selected EasyWatch package set onto the chosen target disk;
3. deploys the captured dashboard/configuration into that new user's home;
4. enables the two user services for that user;
5. configures TTY1 to launch the dashboard by default, with Hyprland optional.

`archinstall` is included as installer tooling, but launching it alone does
not yet deploy all EasyWatch customizations. Do not publish this as a finished
installer until the integration and hardware testing are complete.

## Prepare on an Arch Linux build host

Install `archiso` on a separate build host or suitable build environment.
Then run:

    ./prepare-profile.sh
    ./build-iso.sh

`prepare-profile.sh` copies the currently installed official Archiso releng
profile. The build script uses `sudo mkarchiso`; it does not partition or
install onto the build host.

## Build resources

The captured system has a large 626-package inventory. Expect a large ISO,
substantial download/storage requirements, and a long build. The original
source machine has limited RAM, so a separate build host or CI runner may be
more suitable. No build has been run yet.

## Privacy and licensing

The collection excludes known history/session files and secret-bearing files
that were identified during collection. Still review the complete payload
and licenses before making a public release. Never publish credentials,
private keys, personal browser data, Wi-Fi secrets, or private histories.
