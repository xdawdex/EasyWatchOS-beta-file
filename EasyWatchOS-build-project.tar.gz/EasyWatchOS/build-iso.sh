#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROFILE="$ROOT/profile"
OUT="$ROOT/out"
WORK="$ROOT/work"

if [[ ! -f "$PROFILE/profiledef.sh" ]]; then
    echo "Profile is not prepared. First run: ./prepare-profile.sh"
    exit 1
fi
if ! command -v mkarchiso >/dev/null 2>&1; then
    echo "mkarchiso is missing. Install archiso on the BUILD HOST first."
    exit 1
fi
mkdir -p "$OUT" "$WORK"
echo "Building EasyWatch OS ISO. This downloads packages and uses disk space."
echo "It does not install to or repartition the build host."
sudo mkarchiso -v -w "$WORK" -o "$OUT" "$PROFILE"
echo "Build finished. ISO output is in: $OUT"
